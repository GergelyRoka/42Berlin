/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   my_putxint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: groka <groka@student.42berlin.de>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/06 15:50:08 by groka             #+#    #+#             */
/*   Updated: 2023/02/09 11:50:16 by groka            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "writes.h"

int	my_putxint(unsigned int number)
{
	char	*base;
	long	num;
	int		out;

	base = "0123456789abcdef";
	num = number;
	out = 0;
	if (num / 16 != 0)
		out += my_putxint(num / 16);
	out += my_putchr(base[num % 16]);
	return (out);
}
